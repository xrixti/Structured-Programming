#include<stdio.h>

int main()
{
  int n;
  printf("enter size of array: ");
  scanf("%d",&n);
  int a[n],i,max,index;

  printf("enter elements of array:  ");
  for(i=0;i<n;i++)
  {
      scanf("%d",&a[i]);
  }

  max=a[0];
  index=0;
  for(i=0;i<n;i++)
  {
      if(a[i]>max)
      {
          max=a[i];
          index= i;
      }
  }
    printf("Maximum value is %d at %d index",max,index);
    return 0;
}
